// chapter4-expression.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <iostream>
#include <string>
#include <vector>

using namespace std;


void fundamentals()
{
	// unary operators: * & + - /
	// binary operators: == || >= ++
	// Overloaded operators: The IO library >> and << operators and those used with strings, vectors, and iterators 
	// lvalue: use its identity; rvalue: use its value. e.g. a = 5
	// Order of evaluation: not defined-> >>, <<, +-*/  defined-> ||, &&, comma, ?:
	//		when in doubt, parenthesis them
	// right/left associative operators
	// precedence: https://baike.baidu.com/item/%E8%BF%90%E7%AE%97%E7%AC%A6%E4%BC%98%E5%85%88%E7%BA%A7
}

void arithmetic_operators()
{
	// <<= >>= &= ^= |=  bitwise operators
	// +-*/ have higher precedence than == and !=
	// ��ֵ����������ҽ����
	double i;
	int j;
	i = j = 3.5; // i = 3
}

void increment_operators()
{
	int i = 0, j;
	j = ++i; // j = 1, i = 1: prefix yields the incremented value
	j = i++; // j = 1, i = 2: postfix yields the unincremented value 
	// use ++i instead of i++
	// The precedence of postfix increment is higher than that of the dereference operator
	// so *pbeg++ is equivalent to *(pbeg++).
}

void member_access()
{
	string s1 = "a string", *p = &s1;
	auto n = s1.size(); // run the size member of the string s1
	n = (*p).size(); // run size on the object to which p points
	n = p->size(); // equivalent to (*p).size()
}

void conditional_operator()
{
	int grade = 90;
	string finalgrade = (grade < 60) ? "fail" : "pass";
	finalgrade = (grade > 90) ? "high pass" : (grade < 60) ? "fail" : "pass";
}

void size_of()
{
	int a[] = { 0,2,3,4 };
	constexpr size_t sz = sizeof(a) / sizeof(*a);
	cout << sz << endl;
}

void type_conversion()
{
	// The implicit conversions among the arithmetic types are defined to preserve precision, if possible
	auto a = 3 + 4.3;
	int b = 3 + 4.3; // loss of precision
	cout << a << " " << b << endl;
	// Advice: Avoid Casts  	Casts interfere with normal type checking
}
int main()
{
	fundamentals();
	arithmetic_operators();
	size_of();
	type_conversion();
}

