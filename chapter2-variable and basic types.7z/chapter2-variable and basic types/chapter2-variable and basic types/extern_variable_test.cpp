#include "stdafx.h"
#include <iostream>

extern int const buff_size = 30;
