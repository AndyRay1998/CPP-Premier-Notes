﻿// chapter2-variable and basic types.cpp : 定义控制台应用程序的入口点。
//

#include "stdafx.h"
#include <iostream>
#include "Sales_item.h"
#include <stdio.h>
#include <ctime>
#include "extern_variable_test.h"
#include "Sales_data.h"

using namespace std;

int global_i = 1;

int main()
{
	clock_t t1 = clock(); // for timing

	// **** variable types ****
	bool b = 42; // b is true
	int i = b; // i has value 1
	i = 3.14; // i has value 3
	double pi = i; // pi has value 3.0
	unsigned char c = -1; // assuming 8-bit chars, c has value 255
	signed char c2 = 256; // assuming 8-bit chars, the value of c2 is undefined

	// Caution: Don’t Mix Signed and Unsigned Types
	unsigned u1 = 42, u2 = 10;
	int u3 = 10;
	std::cout << u1 - u2 << std::endl; // ok: result is 32
	std::cout << u2 - u1 << std::endl; // ok: but the result will wrap around
	std::cout << u2 - u3 << std::endl;

	// Two string literals that appear adjacent to one another and that are separated only
	// by spaces, tabs, or newlines are concatenated into a single literal
	std::cout << "a really, really long string literal "
				"that spans two lines" << std::endl;
	/* 
	escape sequences :
		newline      \n  horizontal tab \t  alert(bell)  \a
		vertical tab \v  backspace      \b  double quote \"
		backslash    \\  question mark  \?  single quote \'
		carriage return \r  formfeed    \f

	L'a'     wide character literal, type is wchar_t
	u8"hi!"  utf-8 string literal (utf-8 encodes a Unicode character in 8 bits)
	42ULL    unsigned integer literal, type is unsigned long long
	1E-3F    single-precision floating-point literal, type is float
	3.14159L extended-precision floating-point literal, type is long double
	*/
	std::cout << 3.14159L << std::endl;
	std::cout << 012 << std::endl; //eight jinzhi
	std::cout << L'a' << L"a" << std::endl;
	std::cout << 3.14e1L << std::endl;
	
	// **** initialization ****
	/*
	int units_sold = 0;
	int units_sold = { 0 }; // list initialization
	int units_sold{ 0 };
	int units_sold(0);
	std::string book("iron express");
	*/
	long double ld = 3.1415926536;
	// int a{ ld }, a1 = { ld }; // error: narrowing conversion required
	int d(ld), d1 = ld; // ok: but value will be truncated

	// Uninitialized objects of built-in type defined inside a function body have
	// undefined value.Objects of class type that we do not explicitly initialize have
	// a value that is defined by the class.
	std::string empty; // empty implicitly initialized to the empty string
	Sales_item item; // default-initialized Sales_item object

	// 变量的定义：变量的定义用于为变量分配存储空间，还可以为变量指定初始值。在一个程序中，变量有且仅有一个定义。
	// 变量的声明：用于向程序表明变量的类型和名字。程序中变量可以声明多次，但只能定义一次。
	//（1）定义也是声明，因为当定义变量时我们也向程序表明了它的类型和名字；
	//（2）但声明不是定义，可以通过使用extern关键字声明变量而不定义它。不定义变量的声明包括对象名、对象类型和对象类型前的关键字extern；
	extern int global_i; // declares but does not define i
	int j; // declares and defines j

	// Key Concept: Static Typing, Dynamic Typing, Strong Typing, Weak Typing
	// • An identifier should give some indication of its meaning.
	// • Variable names normally are lowercase—index, not Index or INDEX.
	// • Like Sales_item, classes we define usually begin with an uppercase letter.
	// • Identifiers with multiple words should visually distinguish each word, for example, student_loan or studentLoan, not studentloan.
	
	// scope:作用域 “The scope of name is the part of the program's text in which that name is visible”; delimited by {}
	// The name main is defined outside any curly braces.The name main—like most names defined outside a function—has global scope
	// Concepts: global scope, block scope, inner scope, outer scope
	// 局部变量优先使用，声明extern或者std::可以使用全局变量

	// **** compoud types ****
	// A REFERENCE defines an alternative name for an object. A reference type “refers to”another type.
	int ival = 124;
	int &refval = ival;
	std::cout << "refval = " << refval << std::endl; // NOTE: &refval refers to its address
	// POINTER
	double dp, *dp2; // dp2 is a pointer to double; dp is a double
	int *p = &ival; // p holds the address of ival; p is a pointer to ival
	std::cout << *p << std::endl;
	
	// DO NOT leave a pointer empty. Assign 0 to it.
	int *p1 = nullptr; // equivalent to int *p1 = 0;
	int *p2 = 0; // directly initializes p2 from the literal constant 0 or dereference to be a NULL
	int *p3 = NULL; // equivalent to int *p3 = 0;
	int **pp = &p3; // pointer to a pointer
	int *&pa = p3; // reference to a pointer

	// **** const ****
	int const con = 512; //By Default, const Objects Are Local to a File
	// *p1 = &con; // error:const cannot be assigned to unconst
	int const *p_const = &ival; // ok:unconst can be assigned to const
	cout << "globly defined variable is: " << buff_size << endl; // which is defined in another file and can be used in others
	int const &ref_buff = buff_size;
	
	// ****  const pointer  ****
	//top-level const: the pointer itself is a const
	//low - level const: pointer can point to a const object
	const int *const p4 = &con;
	int *const p5 = &ival;
	
	// ****  const expression  ****
	// A constant expression is an expression whose value cannot change and that can be evaluated at COMPILE time
	// const int limit = 1; // limit is a constant expression
	// const int sz = get_size(); // sz is not a constant expression. Value not known until RUN time
	// constexpr限定在了编译期常量
	constexpr int *p6 = nullptr; // p6 is a constant pointer, like int *const p5
	constexpr int con1 = 5;
	//constexpr const int *p7 = &con1; // p is a constant pointer to the const int i
	//constexpr int *p8 = &ival; // p1 is a constant pointer to the int j

	// ****  type alias  ****
	// type alias is a name that is a synonym for another type.
	typedef double wages; // wages is a synonym for double
	typedef wages base, *p9; // base is a synonym for double, p for double*
	typedef char *pstring;
	const pstring *p10; // p10 is a pointer to a constant pointer to char
	// alias declaration
	using SI = Sales_item; // SI is a synonym for Sales_item

	// ****  auto  ****
	//auto: the type of item is deduced from the type of the result of adding val1 and val2
	auto item1 = con + con1; 
	//auto sz = 0, pi = 3.14; // error: inconsistent types for sz and pi; must have consistent type
	// auto ordinarily ignores top - level consts
	const int ci = 9;
	auto b1 = ci; // b is an int (top-level const in ci is dropped)
	const auto b2 = ci; // if u want to remain const, declare like this
	auto &g = ci; // or we can specify a reference; g is a const int& that is bound to ci

	// ****  decltype  **** returns type of its operand, including top-level
	decltype(con) h = 9;
	// decltype of a parenthesized variable is always a reference
	// decltype((i)) d; // error: d is int& and must be initialized

	// ****  struct type  ****
	Sales_data data1, data2;
	double price = 0.0;
	std::cin >> data1.bookNO >> data1.unit_sold >> price;
	data1.revenue = price * data1.unit_sold;
	std::cin >> data2.bookNO >> data2.unit_sold >> price;
	data2.revenue = data2.unit_sold * price;
	if (data1.bookNO == data2.bookNO) {
		unsigned totalCnt = data1.unit_sold + data2.unit_sold;
		double totalRevenue = data1.revenue + data2.revenue;
		// print: ISBN, total sold, total revenue, average price per book
		std::cout << data1.bookNO << " " << totalCnt
			<< " " << totalRevenue << " ";
		if (totalCnt != 0)
			std::cout << totalRevenue / totalCnt << std::endl;
		else
			std::cout << "(no sales)" << std::endl;
		return 0; // indicate success
	}
	else { // transactions weren't for the same ISBN
		std::cerr << "Data must refer to the same ISBN"
			<< std::endl;
		return -1; // indicate failure
	}

	clock_t t2 = clock(); // for timing
	cout << "TIME SPENT " << (double)(t2 - t1) / CLOCKS_PER_SEC << " s" << endl;
    return 0;
}

