#pragma once
#include <iostream>
#include <string>

extern int const buff_size;