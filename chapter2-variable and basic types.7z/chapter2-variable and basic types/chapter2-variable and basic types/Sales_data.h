#include <iostream>

struct Sales_data {
	std::string bookNO; // data members
	unsigned unit_sold = 0;
	double revenue = 0.0;
};
