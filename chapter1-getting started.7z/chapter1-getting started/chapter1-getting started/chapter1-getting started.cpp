// ConsoleApplication1.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <iostream> // standard lib use <>
#include "Sales_item.h"
using namespace std;

int main()
{
	/*
	// **** IO stream ****
	int v1 = 0, v2 = 0;
	cout << "enter two numbers" << endl; // endl ends the current line and flushes the buffer
	// Flushing the buffer ensures that all the output the
	//program has generated so far is actually written to the
	//output stream, rather than sitting in memory waiting to be written
	cin >> v1 >> v2;
	cout << "shit " << v1 << v2 << endl;
	cerr << "cerr outputs error messages" << endl;

	// The prefix std:: indicates that the names cout and endl are defined inside the namespace
	// named std.Namespaces allow us to avoid inadvertent collisions between the names we define
	// and uses of those same names inside a library.

	std::clog << "clog outputs standard messages" << std::endl;
	*/

	/*
	// **** flow control ****
	while (v1 < 10) {
	++v1;
	}
	cout << "new v1: " << v1 << endl;
	for (v1 = 10; v1 > 1; --v1);
	cout << "new v1: " << v1 << endl;
	// Send all inputs to v1 one by one
	while (std::cin >> v1) { // type ctrl+z to end input
	cout << "v1: " << v1 << endl;
	}
	*/


	Sales_item item1, item2;
	std::cin >> item1 >> item2; // imput ISBN num price
								// When we use the dot operator to access a member function, we usually do so to
								// call that function.We call a function using the call operator (the() operator).
	if (item1.isbn() == item2.isbn()) {
		std::cout << item1 + item2 << std::endl; // print ISBN num total_price avg_price
		return 0;
	}
	else {
		std::cerr << "data types must coincide" << std::endl;
		return -1;
	}

}

