// chapter3-string, vector and array.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <string>
#include <iostream>
#include <vector>

using namespace std;

int main()
{
	// ****  String  ****
	// 1. definition
	string s1 = "abc"; // copy initialization
	string s2("adc"); // direct initialization
	string s3(10, 'c'); // ten 'c' together
	string s4 = string(10, 'c'); // copy initialization; s4 is cccccccccc

/*
	// 2. input and output
	// https://www.cnblogs.com/flatfoosie/archive/2010/12/22/1914055.html
	cin >> s1 >> s2;; // read a whitespace-separated string into s
	cout << s1 << s2 << endl; // write s to the output
	string word; // empty string

	// >> will omit space
	while (cin >> word) // read until end-of-file (which you should input Ctrl+Z in a new line)
		cout << word << endl; // write each word followed by a new line
	string line;

	// read input a line at a time until end-of-file
	// getline will not omit space; also ends with ctrl+Z in a new line
	// getline(cin, str); cin.getline(store string, len, end char e.g. 'a');
	while (getline(cin, line))
		cout << line << endl;
	string line1;
	cout <<  line1.size() << endl;
	while (getline(cin, line1))
		if (!line1.empty()) // discard empty string
			cout << line1 << " " << line1.size() << endl;
	auto len = line1.size(); // len has type string::size_type
	

	// 3. comparison: same characters then compare length; different characters then compare alphebetic sequence
	// e.g. str < phrase < slang
	string str = "Hello";
	string phrase = "Hello World";
	string slang = "Hiya";


	// 4. add: in the first two vars, must have at least one defined string var
	string added = str + phrase;
	string s5 = s2 + ", " + "hello"; // ok
	// string s5 = "hello" + ", " + s2; // error
	

	// 5. dealing with characters in string
	for (auto c : s5) // for every char in str
		if (ispunct(c)) // if the character is punctuation
			continue; // discard punctuation
		else
			cout << c << endl; // print the current character followed by a newline
	for (auto &c : s5) // for every char in s (note: c is a reference)
		c = toupper(c); // c is a reference, so the assignment changes the char	in s
		cout << s5 << endl;
	if (!s5.empty()) // make sure there's a character to print
		cout << s5[0] << endl; // print the first character in s
	*/


	// ****  Vector  ****
	// 1. define and initialize; kind of an instantiationʵ����
	vector<string> svec; // default initialization; svec has no elements
	vector<string> v1(svec); // v1 is a copy of svec
	vector<string> v2(3, "t"); // v2 has 3 copies of "t"
	vector<int> ivec(10, -1); // parentheses means we want to use data inside to construct
	vector<string> v3{ "1", "2", "3" }; // list initialization; can also add a "="
	vector<int> v4(10); // 10 elements to 0
	// vector<int> v5 = 10; // error: must use direct initialization to supply a size
	vector<int> v6 = { 10 };

	// 2. vector operation
	for (int i = 0; i != 10; ++i)
		ivec.push_back(i); // add elements
	string word;
	while (cin >> word) { // do not enter space
		v1.push_back(word);
	}
	for (auto &i : ivec) {
		i *= i;
		cout << i << endl;
	}
	for (auto i : word)
		cout << i << " ";
	cout << word.size() << endl;

	// ****  Iterators  ****
	cout << (v2.begin() == v2.end()) << endl; // if v2 is empty
	// vector.begin vector.end; if we only want to read, then "cbegin" and "cend" with the type "vector<int>::const_iterator"
	vector<int> myvector{ 1, 2, 3, 4, 5 };
	// using begin() to print vector 
	for (auto it = myvector.begin();
		it != myvector.end(); ++it)
		cout << ' ' << *it; // like a pointer
	// arrow operator: it->mem is a synonym for (* it).mem e.g. it->empty()


	// ****  Arrays  ****
	// fixed size: loss of flexibility, better performance
	// 1. Define and assignment
	constexpr unsigned sz = 42;
	int arr[10];
	int *parr[sz];
	string bad[sz]; // ok: because sz is constexpr

	// omission of size & default initialization
	int a1[3] = { 0,1,2 };
	int a2[] = { 0,1,2 };
	int a3[5] = { 0,1,2 };

	// for char arrays
	char a1_[] = { 'C', '+', '+' }; // list initialization, no null
	char a2_[] = { 'C', '+', '+', '\0' }; // list initialization, explicit null
	char a3_[] = "C++"; // null terminator added	automatically
	// const char a4[6] = "Daniel"; // error: no space for the null!

	// no copy or assignment
	// int a2[] = a; // error: cannot initialize one array with another
	// a2 = a; // error: cannot assign one array to another

	// pointer and reference
	int(*Parray)[10] = &arr; // Parray points to arr
	int(&arrRef)[10] = arr; // arrRef refers to arr
	int *ptrarr[10];
	int *(&arrRef1)[10] = ptrarr; // arrRef1 refers to an array of 10 pointers

	// 2. accessing elements inside
	// Buffer Overflow: Such bugs occur when a program fails to check a subscript and mistakenly
	// uses memory outside the range of an array or similar data structure.
	for (auto i : a1)
		cout << i << " ";
	cout << endl;

	// 3. pointer and array
	// pointers are iterators
	string nums[] = { "one", "two", "three" }; // array of strings
	string *p = &nums[0]; // p points to the first element in nums
	string *p2 = nums; // equivalent to p2 = &nums[0]
	// unlike vectors that need vector.begin() or sth, we have to begin(array) or end(array)
	// array is not a class type, so begin and end are not member functions
	string *bg = begin(nums);
	string *ed = end(nums);

	// operations on arrays are often really operations on pointers
	auto a1__(a1); // a1__ is a *int to a1[0]
	auto a2__ = a1__ + 2; // a2__ is a *int to a1[2]
	auto n = a2__ - a1__; // ptrdiff_t type: substraction of two pointers
	bool com_a1_a2 = (a1__ < a2__); // pointers comparison
	cout << *a1__ << endl;
	cout << com_a1_a2 << endl;
	int ia[] = { 3,4,66,4 };
	int *p_ = ia; // p points to the first element in ia
	p_ = p_ + 2;
	cout << *p_ << endl;
	int k = p_[-2]; // now k points to ia[0]
					// the index of the built-in subscript operator is not an unsigned type.
	// OR: int *p = &ia[2]; // p points to the element indexed by 2

	// WARNING: avoid using C-style string

	// interfacing the older code
	// using array to initialize a vector
	vector<int> vec_int_ia(begin(ia), end(ia)); // from begin to end
	vector<int> sub_vec_int_ia(ia[0], ia[2]); // from ia[0] to ia[2]
	// char *str = s1; // error: can't initialize a char* from a string
	const char *str = s1.c_str();


	// ****  Multidimensional Array  ****
	int ma[2][3] = { {0,1,2},{2,4,5} };
	// explicitly initialize only element 0 in each row
	int ma1[3][4] = { { 0 },{ 4 },{ 8 } };
	// explicitly initialize row 0; the remaining elements are value initialized
	int ma2[3][4] = { 0, 3, 6, 9 };

	// access elements in arrays via loops
	constexpr size_t rowCnt = 3, colCnt = 4;
	int ia_[rowCnt][colCnt]; // 12 uninitialized elements
							// for each row
	for (size_t i = 0; i != rowCnt; ++i) {
		// for each column within the row
		for (size_t k = 0; k != colCnt; ++k) {
			// assign the element's positional index as its value
			ia_[i][k] = i * colCnt + k;
		}
	}

	for (auto p_ma1 = ma1; p_ma1 != ma1 + 3; ++p_ma1) {
		// q points to the first element of an array of four ints; that is, q points to an int
			for (auto q_ma1 = *p_ma1; q_ma1 != *p_ma1 + 4; ++q_ma1)
				cout << *q_ma1 << ' ';
		cout << endl;
	}
	
	for (auto p1_ma1 = begin(ma1); p1_ma1 != end(ma1); ++p1_ma1) {
		// q points to the first element in an inner array
		for (auto q1_ma1 = begin(*p1_ma1); q1_ma1 != end(*p1_ma1); ++q1_ma1)
			cout << *q1_ma1 << ' '; // prints the int value to which q points
			cout << endl;
	}

	int (*p_ma1)[4] = ma1; // p points to an array of four ints
	/*int *ip[4]; // array of pointers to int
	int (*ip)[4]; // pointer to an array of four ints*/
	p_ma1 = &ma1[2]; // p now points to the last element in ia

    return 0;
}

