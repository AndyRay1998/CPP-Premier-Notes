// chapter5-statement.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <string>
#include <iostream>

using namespace std;

// ***** 5.1 Simple Statement *****
void simple_statement()
{
	// useless statement
	int ival = 0;
	ival + 5; // useless, bec result is not used

	// usage of null statement: when the language needs but the logic not
	int s;
	// read until we hit end-of-file or find an input equal to sought
	while (cin >> s && s != 0)
		; // null statement

	// Missing or Extraneous Semicolons
	ival += 5;; // ok: second semicolon is a superfluous null statement 
	// superfluous semicolon is harmless, but may change the effect of 'if' and 'while'

	// Compound statement(blocks), namely a scope, e.g. defined function
	// used when the language needs one single statement but logic needs multiple
	while (ival <= 10) {
		++ival; // add 1 to val
	}
	// an empty block is like null statement

}


// ***** 5.2 Statement Scope *****
void statement_scope()
{
	// Local Variables
	// We can define variables inside the control structure of the if, switch, while, and
	// for statements.Variables defined in the control structure are visible only within that
	// statement and are out of scope after the statement ends
}


// ***** 5.3 Conditional Statement *****
void conditional_statement()
{
	// IF
	// Dangling else PROBLEM: which 'else' matches which 'if'
	// 'else' matches nearest unmatched 'if'; execution does NOT match indentation
	// We can control the execution path by adding curly braces

	// SWITCH
	// 'break' tells the compiler to continue across other 'case' once matched
	// sometimes we omit 'break' for common actions of 'case'
	unsigned vowelCnt = 0;
	char ch;
	cin >> ch;
	switch (ch)
	{
		// alternative legal syntax
		case 'a': case 'e': case 'i': case 'o': case 'u':
			++vowelCnt;
			break;
	}
	// without 'break', once matched, program continues to execute all actions appearing in after 'case'
}


// ***** 5.4 Iterative Statements *****
void iterative_statements()
{
	// FOR
	// traditional FOR
	// for (int i =0; i<10; i++)
	// range FOR
	// for (i : <vector>)  for (auto &r : <vector>)
}


// ***** 5.5 Jump Statements *****
void jump_statements()
{
	// Jump statements terminate flow of execution

	// BREAK
	// A break statement terminates the nearest enclosing while, do while, for, or switch statement
	// A break affects only	the nearest enclosing loop or switch

	// CONTINUE
	// A continue statement terminates the current iteration of the nearest enclosing loop /
	// and immediately begins the next iteration.A continue can appear only inside a for, /
	// while, or do while loop,
	
	// GOTO
	// goto flag;
	// flag: expression;

	// TRY EXCEPT
	try
	{
		// expression;
		cerr << "artificial error" << endl;
		throw 0;
	}
	catch (...)
	{
		cout << "error catched!" << endl;
	}

}


int main()
{
	// simple_statement();
	// conditional_statement();
	jump_statements();
    return 0;
}

